package com.example.infection_servicediscovery;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.util.Log;

public class DiscoverServices {


    private NsdManager nsdManager;
    private NsdManager.DiscoveryListener discoveryListener;
    Context context;

    public DiscoverServices(Context context) {
        this.context = context;
        nsdManager = (NsdManager) context.getSystemService(Context.NSD_SERVICE);
    }

    public void discover(){
        nsdManager.discoverServices(
                RegisterNetworkService.serviceType, NsdManager.PROTOCOL_DNS_SD, discoveryListener);
    }

    public void removeDiscoveryListener(){
        discoveryListener = null;
    }

    public void initializeDiscoveryListener() {

        // Instantiate a new DiscoveryListener
        discoveryListener = new NsdManager.DiscoveryListener() {

            // Called as soon as service discovery begins.
            @Override
            public void onDiscoveryStarted(String regType) {
                Log.d("hello test ", "Service discovery started");
            }

            @Override
            public void onServiceFound(NsdServiceInfo service) {
                // A service was found! Do something with it.
                Log.d("hello test ", "Service discovery success" + service);

                String serviceName = service.getServiceName();

                if (serviceName.startsWith(BuildConfig.APPLICATION_ID)){
                    Log.v("hello test ","Our service found! " + serviceName);



                }else{
                    Log.v("hello test ", "Our service wasn't found. " + serviceName);
                }
            }

            @Override
            public void onServiceLost(NsdServiceInfo service) {
                // When the network service is no longer available.
                // Internal bookkeeping code goes here.
                Log.e("hello test ", "service lost: " + service);
            }

            @Override
            public void onDiscoveryStopped(String serviceType) {
                Log.i("hello test ", "Discovery stopped: " + serviceType);
            }

            @Override
            public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                Log.e("hello test ", "Discovery failed: Error code:" + errorCode);
                nsdManager.stopServiceDiscovery(this);
            }

            @Override
            public void onStopDiscoveryFailed(String serviceType, int errorCode) {
                Log.e("hello test ", "Discovery failed: Error code:" + errorCode);
                nsdManager.stopServiceDiscovery(this);
            }
        };
    }
}
