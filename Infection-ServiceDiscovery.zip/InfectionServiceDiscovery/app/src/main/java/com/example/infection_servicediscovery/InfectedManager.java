package com.example.infection_servicediscovery;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class InfectedManager {

    Context context;
    String state;
    HashMap<String, String> otherState = new HashMap<>();



    public InfectedManager(Context context, String state) {
        this.context = context;

        // Creates a lookup table used to remove the previous network service
        otherState.put("infected","clean");
        otherState.put("clean", "infected");
    }

    // Updates shared preference 'state'key with the new state.
    private void updatedSharedPref(){

        Activity activity = (Activity) context;
        SharedPreferences sharedPref = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("state",state);

        editor.apply();


    }

    private void sendPushNotification(){

    }

    /**
     * Removes the current network services and creates a new one for the new state.
     */
    private void updateService(){
        RegisterNetworkService resisterNetworkService = new RegisterNetworkService(context);
        resisterNetworkService.unregisterService(resisterNetworkService.localPort,otherState.get(state));

        resisterNetworkService.initializeServerSocket();
        resisterNetworkService.initializeRegistrationListener();
        resisterNetworkService.registerService(resisterNetworkService.localPort, state);
    }
}
